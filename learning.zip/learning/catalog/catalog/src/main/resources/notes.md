create table user (
id integer not null,
birth_date timestamp,
name varchar(255),
primary key(id))



runtimeOnly 'com.h2database:h2'

spring.jpa.show-sql=true
spring.h2.console.enabled=true
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.security.user.name
spring.security.user.password
