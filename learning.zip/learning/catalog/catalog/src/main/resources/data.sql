insert into User(id,birth_date,name) values(100,sysdate(),'AB');
insert into User(id,birth_date,name) values(200,sysdate(),'ABC');
insert into User(id,birth_date,name) values(300,sysdate(),'ABD');
insert into Post(POST_ID,USER_ID,DESCRIPTION) values(5000,100,'1st post');
insert into Post(POST_ID,USER_ID,DESCRIPTION) values(5001,100,'2nd post');
