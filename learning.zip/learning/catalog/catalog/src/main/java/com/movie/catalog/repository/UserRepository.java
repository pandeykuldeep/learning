package com.movie.catalog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movie.catalog.model.User;

public interface  UserRepository extends JpaRepository<User,Integer> {

}
