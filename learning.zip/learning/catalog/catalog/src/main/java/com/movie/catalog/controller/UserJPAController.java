package com.movie.catalog.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.movie.catalog.exception.UserNotFoundException;
import com.movie.catalog.model.Post;
import com.movie.catalog.model.User;
import com.movie.catalog.repository.PostRepository;
import com.movie.catalog.repository.UserRepository;
import com.movie.catalog.service.UserDaoService;

@RestController
public class UserJPAController {
	
	//RetriveCll Users;
	
		@Autowired
		UserDaoService userDaoService;
		
		@Autowired
		UserRepository userRepository;
		
		@Autowired
		PostRepository postRepository;
		
		@GetMapping(path= "/jpa/users")
		public List<User> getAllUsers()
		{
			System.out.println("Get All Users");
			return userRepository.findAll();
			
		}

		@GetMapping(path= "/jpa/user/{userId}")
		public User getUser(@PathVariable Integer userId )  
		{
			
			Optional<User> user= userRepository.findById(userId);
			if(!user.isPresent())
			{
				throw new UserNotFoundException("userID: "+userId);
			}
			return user.get() ;
			
		}
		
		@PostMapping(path = "/jpa/user")
		public ResponseEntity<Object> saveJPAUser(@Valid @RequestBody User user) {
			User savedUser = userRepository.save(user);
			URI location = ServletUriComponentsBuilder.fromCurrentRequest().
					path("/{id}").buildAndExpand(savedUser.getId())
					.toUri();

			return ResponseEntity.created(location).build();
		}
		
		@DeleteMapping(path= "/jpa/user/{userId}")
		public void deleteUser(@PathVariable Integer userId )  
		{
			Optional<User> user= userRepository.findById(userId);
			if(!user.isPresent())
			{
				throw new UserNotFoundException("userID: "+userId);
			}
			userRepository.deleteById(userId);
							
		}
		
		@GetMapping(path= "/jpa/user/{userId}/posts")
		public List<Post> getAllPosts(@PathVariable Integer userId)
		{
			
			Optional<User> optionalUser=userRepository.findById(userId);
			if(!optionalUser.isPresent())
			{
				throw new UserNotFoundException("userID: "+userId);
			}
			
			return optionalUser.get().getPosts();
			
		}
		
		
		@PostMapping(path = "/jpa/{userId}/post")
		public ResponseEntity<Object> createPost(@PathVariable Integer userId , @RequestBody Post post) {
			Optional<User> user= userRepository.findById(userId);
			if(!user.isPresent())
			{
				throw new UserNotFoundException("userID: "+user.get().getId());
			}
			post.setUser(user.get());
			Post optionalPost=postRepository.save(post);
			URI location = ServletUriComponentsBuilder.fromCurrentRequest().
					path("/{postId}").buildAndExpand(optionalPost.getPostId())
					.toUri();

			return ResponseEntity.created(location).build();
		}
		
		
		

}
