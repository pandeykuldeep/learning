package com.movie.catalog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movie.catalog.model.Post;

public interface PostRepository extends JpaRepository<Post, Integer> {

}
