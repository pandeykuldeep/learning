package com.movie.catalog.controller;

import java.net.URI;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.http.ResponseEntity;

import com.movie.catalog.exception.UserNotFoundException;
import com.movie.catalog.model.User;
import com.movie.catalog.service.UserDaoService;

@RestController
public class UserController {
	
	//RetriveCll Users;
	
	@Autowired
	UserDaoService userDaoService;
	
	@GetMapping(path= "/users")
	public List<User> getAllUsers()
	{
		
		return userDaoService.findAll();
		
	}

	@GetMapping(path= "/user/{userId}")
	public User getUser(@PathVariable Integer userId )  
	{
		
		User user= userDaoService.findOne(userId);
		if(user== null)
		{
			throw new UserNotFoundException("userID: "+userId);
		}
		return user ;
		
	}
	
	@PostMapping(path = "/user")
	public ResponseEntity<Object> saveUser(@Valid @RequestBody User user) {
		User savedUser = userDaoService.saveUser(user);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().
				path("/{id}").buildAndExpand(savedUser.getId())
				.toUri();

		return ResponseEntity.created(location).build();
	}
	
	@DeleteMapping(path= "/user/{userId}")
	public void deleteUser(@PathVariable Integer userId )  
	{
		
		User user= userDaoService.deleteUser(userId);
		if(user== null)
		{
			throw new UserNotFoundException("userID: "+userId);
		}
			
	}
	
}
