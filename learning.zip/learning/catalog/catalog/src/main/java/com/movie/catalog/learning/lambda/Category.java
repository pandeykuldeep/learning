package com.movie.catalog.learning.lambda;

public class Category {

	
}
