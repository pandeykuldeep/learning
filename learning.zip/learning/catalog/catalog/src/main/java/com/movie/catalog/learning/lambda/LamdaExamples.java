package com.movie.catalog.learning.lambda;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LamdaExamples {
	
	public static void main(String[] args) {
		
		Map<Category,List<Book>> booksByCategory=new HashMap<>();
        List<Book>  books= new ArrayList<Book>();
		iterativeMethod(booksByCategory, books);
		
	}

	private static void iterativeMethod(Map<Category, List<Book>> booksByCategory, List<Book> books) {
		for (Book book:books)
		{
			if(book.getRating()>= 4.5){
				Category c=book.getCategory();
				List<Book> bookList=booksByCategory.get(c);
				if(bookList==null)
				{
					bookList=new ArrayList<>();
					booksByCategory.put(c, bookList);
					
				}
				bookList.add(book);
			}
			
		}
	}

}
